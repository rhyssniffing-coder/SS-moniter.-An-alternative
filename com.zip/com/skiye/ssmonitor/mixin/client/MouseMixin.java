package com.skiye.ssmonitor.mixin.client;

import com.skiye.ssmonitor.client.RawClickTracker;
import net.minecraft.class_11910;
import net.minecraft.class_310;
import net.minecraft.class_312;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_312.class)
abstract class MouseMixin {
    @Shadow @Final private class_310 client;

    @Inject(method = "onMouseButton", at = @At("HEAD"))
    private void ssmonitor$recordPrimaryPress(long window, class_11910 input, int action, CallbackInfo callback) {
        if (action == GLFW.GLFW_PRESS
                && input.comp_4801() == GLFW.GLFW_MOUSE_BUTTON_LEFT
                && client.field_1755 == null) {
            RawClickTracker.recordPrimaryPress();
        }
    }
}
