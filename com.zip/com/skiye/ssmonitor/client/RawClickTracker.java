package com.skiye.ssmonitor.client;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** Captures raw primary-button press intervals before Minecraft's tick sampling. */
public final class RawClickTracker {
    private static final int MAX_SAMPLES = 128;
    private static final int MIN_SAMPLES_TO_REPORT = 16;
    private static final long MAX_GAP_NANOS = 1_000_000_000L;
    private static final long REPORT_INTERVAL_NANOS = 2_000_000_000L;
    private static final ArrayDeque<Long> presses = new ArrayDeque<>();

    private static long lastReportAt;

    private RawClickTracker() {
    }

    public static synchronized void recordPrimaryPress() {
        long now = System.nanoTime();
        Long previous = presses.peekLast();
        if (previous != null && now - previous > MAX_GAP_NANOS) {
            presses.clear();
        }
        presses.addLast(now);
        while (presses.size() > MAX_SAMPLES) {
            presses.removeFirst();
        }
    }

    public static synchronized List<Long> intervalsForReport() {
        long now = System.nanoTime();
        Long latest = presses.peekLast();
        if (latest == null
                || presses.size() < MIN_SAMPLES_TO_REPORT
                || now - latest > MAX_GAP_NANOS
                || now - lastReportAt < REPORT_INTERVAL_NANOS) {
            return List.of();
        }
        lastReportAt = now;
        List<Long> intervals = new ArrayList<>(presses.size() - 1);
        long previous = 0L;
        for (long press : presses) {
            if (previous != 0L) {
                intervals.add((press - previous) / 1_000L);
            }
            previous = press;
        }
        return List.copyOf(intervals);
    }

    public static synchronized void clear() {
        presses.clear();
        lastReportAt = 0L;
    }
}
