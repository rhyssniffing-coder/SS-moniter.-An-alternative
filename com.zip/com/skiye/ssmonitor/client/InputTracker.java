package com.skiye.ssmonitor.client;

import net.minecraft.class_310;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public final class InputTracker {

    private final AtomicBoolean leftPressed = new AtomicBoolean(false);
    private final AtomicBoolean rightPressed = new AtomicBoolean(false);
    private final AtomicInteger clickCount = new AtomicInteger(0);

    private long lastX;
    private long lastY;
    private long lastLookX;
    private long lastLookY;
    private long deltaX;
    private long deltaY;
    private long deltaLookX;
    private long deltaLookY;

    private boolean initialized;

    public InputTracker() {
    }

    public void sample(class_310 client) {
        if (client.field_1724 == null) return;

        long mouseX = (long) client.field_1690.field_1851;
        long mouseY = (long) client.field_1690.field_1852;
        float yaw = client.field_1724.method_36456();
        float pitch = client.field_1724.method_36454();

        if (!initialized) {
            lastX = mouseX;
            lastY = mouseY;
            lastLookX = (long) yaw;
            lastLookY = (long) pitch;
            initialized = true;
            return;
        }

        deltaX = mouseX - lastX;
        deltaY = mouseY - lastY;
        deltaLookX = (long) yaw - lastLookX;
        deltaLookY = (long) pitch - lastLookY;

        lastX = mouseX;
        lastY = mouseY;
        lastLookX = (long) yaw;
        lastLookY = (long) pitch;
    }

    public void onLeftClick() {
        if (leftPressed.compareAndSet(false, true)) {
            clickCount.incrementAndGet();
        }
    }

    public void onLeftRelease() {
        leftPressed.set(false);
    }

    public void onRightClick() {
        rightPressed.compareAndSet(false, true);
    }

    public void onRightRelease() {
        rightPressed.set(false);
    }

    public int getClickCount() {
        return clickCount.getAndSet(0);
    }

    public long getDeltaX() { return deltaX; }
    public long getDeltaY() { return deltaY; }
    public long getDeltaLookX() { return deltaLookX; }
    public long getDeltaLookY() { return deltaLookY; }
    public boolean isLeftPressed() { return leftPressed.get(); }
    public boolean isRightPressed() { return rightPressed.get(); }
}
