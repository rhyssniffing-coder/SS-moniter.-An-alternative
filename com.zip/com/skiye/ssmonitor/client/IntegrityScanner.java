package com.skiye.ssmonitor.client;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.metadata.ModOrigin;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class IntegrityScanner {
    private final SSMonitorConfig config;
    private final Map<String, HashCacheEntry> fileHashCache =
            new HashMap<>();
    private Map<String, ModSnapshot> previousSnapshot =
            new HashMap<>();

    private boolean baselineCreated;
    private String previousSelfHash = "";

    public IntegrityScanner(SSMonitorConfig config) {
        this.config = config;
    }

    public ScanResult scan() {
        Map<String, ModSnapshot> current =
                collectMods();

        List<Change> changes =
                new ArrayList<>();

        if (!baselineCreated) {
            baselineCreated = true;
        } else {
            compare(
                    previousSnapshot,
                    current,
                    changes
            );
        }

        previousSnapshot = current;

        String selfHash =
                calculateSelfHash();

        if (
                !previousSelfHash.isBlank()
                        && !previousSelfHash.equals(selfHash)
        ) {
            changes.add(
                    new Change(
                            "SELF_INTEGRITY_CHANGED",
                            SSMonitorClient.MOD_ID,
                            previousSelfHash,
                            selfHash
                    )
            );
        }

        previousSelfHash = selfHash;

        return new ScanResult(
                current,
                changes,
                selfHash
        );
    }

    private Map<String, ModSnapshot> collectMods() {
        Map<String, ModSnapshot> output =
                new HashMap<>();

        Collection<ModContainer> mods =
                FabricLoader
                        .getInstance()
                        .getAllMods();

        for (ModContainer mod : mods) {
            String id =
                    mod.getMetadata().getId();

            String version =
                    mod.getMetadata()
                            .getVersion()
                            .getFriendlyString();

            ModOrigin origin =
                    mod.getOrigin();

            String originKind =
                    origin.getKind().name();

            List<FileSnapshot> files =
                    new ArrayList<>();

            String parentId = "";

            String parentLocation = "";

            if (
                    origin.getKind()
                            == ModOrigin.Kind.PATH
            ) {
                for (Path path : origin.getPaths()) {
                    files.add(
                            snapshotFile(path)
                    );
                }
            }

            if (
                    origin.getKind()
                            == ModOrigin.Kind.NESTED
            ) {
                try {
                    parentId =
                            origin.getParentModId();

                    parentLocation =
                            origin.getParentSubLocation();
                } catch (UnsupportedOperationException ignored) {
                }
            }

            String containingMod = "";

            try {
                containingMod =
                        mod.getContainingMod()
                                .map(
                                        parent ->
                                                parent.getMetadata()
                                                        .getId()
                                )
                                .orElse("");
            } catch (Throwable ignored) {
            }

            List<String> containedMods =
                    new ArrayList<>();

            try {
                for (
                        ModContainer child :
                        mod.getContainedMods()
                ) {
                    containedMods.add(
                            child.getMetadata()
                                    .getId()
                    );
                }
            } catch (Throwable ignored) {
            }

            containedMods.sort(
                    String::compareTo
            );

            ModSnapshot snapshot =
                    new ModSnapshot(
                            id,
                            mod.getMetadata().getName(),
                            version,
                            originKind,
                            parentId,
                            parentLocation,
                            containingMod,
                            containedMods,
                            files
                    );

            output.put(id, snapshot);
        }

        return output;
    }

    private FileSnapshot snapshotFile(Path path) {
        String normalizedPath =
                path.toAbsolutePath()
                        .normalize()
                        .toString();
        boolean regular =
                Files.isRegularFile(path);

        long size = 0L;
        long modified = 0L;
        String hash = "";

        try {
            if (regular) {
                size = Files.size(path);

                FileTime fileTime =
                        Files.getLastModifiedTime(
                                path
                        );

                modified =
                        fileTime.toMillis();

                if (config.reportFileHashes()) {
                    hash = hashFile(path, normalizedPath, size, modified);
                }
            }
        } catch (Throwable ignored) {
            hash = "unavailable";
        }

        String pathHash =
                sha256Bytes(
                        normalizedPath.getBytes(
                                StandardCharsets.UTF_8
                        )
                );

        return new FileSnapshot(
                pathHash,
                regular,
                size,
                modified,
                hash
        );
    }

    private String hashFile(Path path, String normalizedPath, long size, long modified) {
        long now = System.currentTimeMillis();
        HashCacheEntry cached = fileHashCache.get(normalizedPath);
        if (cached != null
                && cached.size() == size
                && cached.modified() == modified
                && now - cached.checkedAt() < config.getFileHashRefreshSeconds() * 1_000L) {
            return cached.hash();
        }
        String hash = sha256(path);
        fileHashCache.put(normalizedPath, new HashCacheEntry(size, modified, now, hash));
        return hash;
    }

    private void compare(
            Map<String, ModSnapshot> previous,
            Map<String, ModSnapshot> current,
            List<Change> changes
    ) {
        for (String id : current.keySet()) {
            if (!previous.containsKey(id)) {
                changes.add(
                        new Change(
                                "MOD_ADDED",
                                id,
                                "",
                                current.get(id).version()
                        )
                );
                continue;
            }

            ModSnapshot before =
                    previous.get(id);

            ModSnapshot after =
                    current.get(id);

            if (!before.coreEquals(after)) {
                changes.add(
                        new Change(
                                "MOD_CHANGED",
                                id,
                                before.version(),
                                after.version()
                        )
                );
            }

            if (!before.files.equals(after.files)) {
                changes.add(
                        new Change(
                                "MOD_FILE_CHANGED",
                                id,
                                before.fileFingerprint(),
                                after.fileFingerprint()
                        )
                );
            }

            if (
                    !before
                            .fileHashes()
                            .equals(after.fileHashes())
            ) {
                changes.add(
                        new Change(
                                "MOD_HASH_CHANGED",
                                id,
                                before.fileFingerprint(),
                                after.fileFingerprint()
                        )
                );
            }
        }

        for (String id : previous.keySet()) {
            if (!current.containsKey(id)) {
                changes.add(
                        new Change(
                                "MOD_REMOVED",
                                id,
                                previous.get(id).version(),
                                ""
                        )
                );
            }
        }
    }

    private String calculateSelfHash() {
        try {
            ModContainer container =
                    FabricLoader
                            .getInstance()
                            .getModContainer(
                                    SSMonitorClient.MOD_ID
                            )
                            .orElse(null);

            if (container == null) {
                return "unavailable";
            }

            if (
                    container.getOrigin().getKind()
                            == ModOrigin.Kind.PATH
            ) {
                for (
                        Path path :
                        container
                                .getOrigin()
                                .getPaths()
                ) {
                    if (Files.isRegularFile(path)) {
                        String normalizedPath = path.toAbsolutePath().normalize().toString();
                        return hashFile(path, normalizedPath, Files.size(path), Files.getLastModifiedTime(path).toMillis());
                    }
                }

                for (
                        Path path :
                        container
                                .getOrigin()
                                .getPaths()
                ) {
                    if (Files.isDirectory(path)) {
                        return directoryFingerprint(path);
                    }
                }
            }

            return "non_path_origin";
        } catch (Throwable ignored) {
            return "hash_error";
        }
    }

    private String directoryFingerprint(Path root) {
        try {
            List<String> entries =
                    new ArrayList<>();

            try (
                    var stream =
                            Files.walk(root)
            ) {
                stream
                        .filter(Files::isRegularFile)
                        .sorted(
                                Comparator.comparing(
                                        Path::toString
                                )
                        )
                        .forEach(
                                path -> {
                                    try {
                                        entries.add(
                                                path
                                                        .toAbsolutePath()
                                                        .normalize()
                                                        .toString()
                                                        + ":"
                                                        + Files.size(path)
                                                        + ":"
                                                        + Files.getLastModifiedTime(path)
                                                        .toMillis()
                                        );
                                    } catch (Throwable ignored) {
                                    }
                                }
                        );
            }

            return sha256Bytes(
                    String.join(
                            "\n",
                            entries
                    ).getBytes(
                            StandardCharsets.UTF_8
                    )
            );
        } catch (Throwable ignored) {
            return "directory_hash_error";
        }
    }

    private String sha256(Path path) {
        try (
                InputStream input =
                        Files.newInputStream(path)
        ) {
            MessageDigest digest =
                    MessageDigest.getInstance(
                            "SHA-256"
                    );

            byte[] buffer =
                    new byte[16384];

            int read;

            while (
                    (read = input.read(buffer))
                            != -1
            ) {
                digest.update(
                        buffer,
                        0,
                        read
                );
            }

            return hex(
                    digest.digest()
            );
        } catch (Throwable ignored) {
            return "hash_error";
        }
    }

    private String sha256Bytes(byte[] data) {
        try {
            return hex(
                    MessageDigest
                            .getInstance("SHA-256")
                            .digest(data)
            );
        } catch (Throwable ignored) {
            return "hash_error";
        }
    }

    private String hex(byte[] bytes) {
        StringBuilder builder =
                new StringBuilder(
                        bytes.length * 2
                );

        for (byte value : bytes) {
            builder.append(
                    String.format(
                            "%02x",
                            value
                    )
            );
        }

        return builder.toString();
    }

    public record ScanResult(
            Map<String, ModSnapshot> mods,
            List<Change> changes,
            String selfHash
    ) {
    }

    public record Change(
            String type,
            String modId,
            String before,
            String after
    ) {
    }

    public record FileSnapshot(
            String pathHash,
            boolean regular,
            long size,
            long modified,
            String sha256
    ) {
    }

    private record HashCacheEntry(long size, long modified, long checkedAt, String hash) {
    }

    public record ModSnapshot(
            String id,
            String name,
            String version,
            String originKind,
            String parentId,
            String parentLocation,
            String containingMod,
            List<String> containedMods,
            List<FileSnapshot> files
    ) {
        public boolean coreEquals(
                ModSnapshot other
        ) {
            return id.equals(other.id)
                    && name.equals(other.name)
                    && version.equals(other.version)
                    && originKind.equals(other.originKind)
                    && parentId.equals(other.parentId)
                    && parentLocation.equals(other.parentLocation)
                    && containingMod.equals(other.containingMod)
                    && containedMods.equals(
                    other.containedMods
            );
        }

        public String fileFingerprint() {
            StringBuilder builder =
                    new StringBuilder();

            for (FileSnapshot file : files) {
                builder.append(
                                file.pathHash()
                        )
                        .append(':')
                        .append(
                                file.size()
                        )
                        .append(':')
                        .append(
                                file.modified()
                        )
                        .append(':')
                        .append(
                                file.sha256()
                        )
                        .append(';');
            }

            return builder.toString();
        }

        public List<String> fileHashes() {
            return files.stream()
                    .map(
                            FileSnapshot::sha256
                    )
                    .toList();
        }
    }
}
