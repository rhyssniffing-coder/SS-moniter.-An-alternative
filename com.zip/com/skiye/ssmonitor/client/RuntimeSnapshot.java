package com.skiye.ssmonitor.client;

import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class RuntimeSnapshot {
    private final String javaVersion;
    private final String javaVendor;
    private final String vmName;
    private final String vmVersion;
    private final List<String> agentTypes;
    private final List<String> agentValueHashes;
    private final String classpathHash;
    private final String libraryPathHash;
    private final String inputArgumentsHash;
    private final String bootModulesHash;

    public RuntimeSnapshot() {
        javaVersion =
                System.getProperty(
                        "java.version",
                        ""
                );

        javaVendor =
                System.getProperty(
                        "java.vendor",
                        ""
                );

        vmName =
                System.getProperty(
                        "java.vm.name",
                        ""
                );

        vmVersion =
                System.getProperty(
                        "java.vm.version",
                        ""
                );

        List<String> types =
                new ArrayList<>();

        List<String> valueHashes =
                new ArrayList<>();

        List<String> inputArguments = new ArrayList<>(
                ManagementFactory.getRuntimeMXBean().getInputArguments()
        );

        for (
                String argument :
                inputArguments
        ) {
            if (
                    argument.startsWith(
                            "-javaagent:"
                    )
            ) {
                types.add(
                        "JAVA_AGENT"
                );

                valueHashes.add(
                        hashValue(
                                argument
                                        .substring(
                                                "-javaagent:"
                                                        .length()
                                        )
                        )
                );
            } else if (
                    argument.startsWith(
                            "-agentlib:"
                    )
            ) {
                types.add(
                        "AGENT_LIB"
                );

                valueHashes.add(
                        hashValue(
                                argument
                                        .substring(
                                                "-agentlib:"
                                                        .length()
                                        )
                        )
                );
            } else if (
                    argument.startsWith(
                            "-agentpath:"
                    )
            ) {
                types.add(
                        "AGENT_PATH"
                );

                valueHashes.add(
                        hashValue(
                                argument
                                        .substring(
                                                "-agentpath:"
                                                        .length()
                                        )
                        )
                );
            }
        }

        agentTypes = List.copyOf(types);
        agentValueHashes = List.copyOf(valueHashes);

        classpathHash =
                hashValue(
                        System.getProperty(
                                "java.class.path",
                                ""
                        )
                );

        libraryPathHash =
                hashValue(
                        System.getProperty(
                                "java.library.path",
                                ""
                        )
                );

        inputArgumentsHash = hashValues(inputArguments);
        bootModulesHash = hashValues(
                ModuleLayer.boot().modules().stream().map(Module::getName).toList()
        );
    }

    public String toJson() {
        return "{"
                + "\"java_version\":\""
                + JsonUtil.escape(javaVersion)
                + "\","
                + "\"java_vendor\":\""
                + JsonUtil.escape(javaVendor)
                + "\","
                + "\"vm_name\":\""
                + JsonUtil.escape(vmName)
                + "\","
                + "\"vm_version\":\""
                + JsonUtil.escape(vmVersion)
                + "\","
                + "\"agent_types\":"
                + JsonUtil.stringArray(agentTypes)
                + ","
                + "\"agent_value_hashes\":"
                + JsonUtil.stringArray(agentValueHashes)
                + ","
                + "\"classpath_hash\":\""
                + JsonUtil.escape(classpathHash)
                + "\","
                + "\"library_path_hash\":\""
                + JsonUtil.escape(libraryPathHash)
                + "\""
                + ",\"input_arguments_hash\":\""
                + JsonUtil.escape(inputArgumentsHash)
                + "\""
                + ",\"boot_modules_hash\":\""
                + JsonUtil.escape(bootModulesHash)
                + "\""
                + "}";
    }

    private static String hashValue(String value) {
        return JsonUtil.sha256(
                value.getBytes(
                        java.nio.charset.StandardCharsets.UTF_8
                )
        );
    }

    private static String hashValues(List<String> values) {
        return hashValue(
                values.stream()
                        .sorted(Comparator.naturalOrder())
                        .reduce("", (left, right) -> left + "\n" + right)
        );
    }
}
