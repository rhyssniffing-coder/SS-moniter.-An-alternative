package com.skiye.ssmonitor.client;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.Properties;

public final class SSMonitorConfig {

    private boolean reportEnabled;
    private boolean consentRequired;
    private String serverPublicKey;
    private String encryptionAlgorithm;
    private int scanSeconds;
    private int maxRetries;
    private long retryBaseDelay;
    private long retryMaxDelay;
    private long reportInterval;
    private int inputSampleTicks;
    private int mouseSampleWindow;
    private boolean reportJson;
    private boolean reportModules;
    private boolean reportClipboard;
    private boolean reportExternalDlls;
    private boolean reportProcessList;
    private boolean logDetections;
    private boolean scanPrefetch;
    private boolean scanRegistry;
    private boolean scanWindows;

    private final Path configPath;

    public SSMonitorConfig(Path configPath) {
        this.configPath = configPath;
    }

    public void load() throws IOException {
        Properties props = new Properties();

        if (Files.exists(configPath)) {
            try (var in = Files.newInputStream(configPath)) {
                props.load(in);
            }
        }

        reportEnabled = parseBoolean(
                props, "report.enabled", false
        );
        consentRequired = parseBoolean(
                props, "consent.required", true
        );
        serverPublicKey = getString(
                props, "server.public_key", ""
        );
        encryptionAlgorithm = getString(
                props, "encryption.algorithm", "NONE"
        );
        scanSeconds = getInt(props, "scan.seconds", 300);
        maxRetries = getInt(props, "max.retries", 5);
        retryBaseDelay = getLong(props, "retry.base_delay", 1000L);
        retryMaxDelay = getLong(props, "retry.max_delay", 30000L);
        reportInterval = getLong(props, "report.interval", 60000L);
        inputSampleTicks = getInt(props, "input.sample_ticks", 20);
        mouseSampleWindow = getInt(props, "mouse.sample_window", 10);
        reportJson = parseBoolean(props, "report.json", true);
        reportModules = parseBoolean(props, "report.modules", true);
        reportClipboard = parseBoolean(props, "report.clipboard", true);
        reportExternalDlls = parseBoolean(
                props, "report_external_dlls", true
        );
        reportProcessList = parseBoolean(
                props, "report_process_list", true
        );
        logDetections = parseBoolean(props, "log.detections", true);
        scanPrefetch = parseBoolean(props, "scan.prefetch", true);
        scanRegistry = parseBoolean(props, "scan.registry", true);
        scanWindows = parseBoolean(props, "scan.windows", true);
    }

    public void save() throws IOException {
        Properties props = new Properties();
        props.setProperty("report.enabled", String.valueOf(reportEnabled));
        props.setProperty("consent.required", String.valueOf(consentRequired));
        props.setProperty("server.public_key", serverPublicKey);
        props.setProperty("encryption.algorithm", encryptionAlgorithm);
        props.setProperty("scan.seconds", String.valueOf(scanSeconds));
        props.setProperty("max.retries", String.valueOf(maxRetries));
        props.setProperty("retry.base_delay", String.valueOf(retryBaseDelay));
        props.setProperty("retry.max_delay", String.valueOf(retryMaxDelay));
        props.setProperty("report.interval", String.valueOf(reportInterval));
        props.setProperty("input.sample_ticks", String.valueOf(inputSampleTicks));
        props.setProperty("mouse.sample_window", String.valueOf(mouseSampleWindow));
        props.setProperty("report.json", String.valueOf(reportJson));
        props.setProperty("report.modules", String.valueOf(reportModules));
        props.setProperty("report.clipboard", String.valueOf(reportClipboard));
        props.setProperty("report_external_dlls", String.valueOf(reportExternalDlls));
        props.setProperty("report_process_list", String.valueOf(reportProcessList));
        props.setProperty("log.detections", String.valueOf(logDetections));
        props.setProperty("scan.prefetch", String.valueOf(scanPrefetch));
        props.setProperty("scan.registry", String.valueOf(scanRegistry));
        props.setProperty("scan.windows", String.valueOf(scanWindows));

        try (var out = Files.newOutputStream(configPath)) {
            props.store(out, "SS Monitor configuration");
        }
    }

    public Path getConfigDir() {
        return configPath.getParent();
    }

    public Path getDetectionsDir() {
        Path dir = getConfigDir().resolve("detections");
        try {
            Files.createDirectories(dir);
        } catch (IOException ignored) {
        }
        return dir;
    }

    public void writeDetectionLog(String type, String detail) {
        if (!logDetections) return;

        try {
            String filename = type + "_" + Instant.now().toEpochMilli() + ".log";
            Path logFile = getDetectionsDir().resolve(filename);
            String content = "type=" + type + "\n"
                    + "time=" + Instant.now() + "\n"
                    + "detail=" + detail + "\n";
            Files.writeString(logFile, content);
        } catch (Exception ignored) {
        }
    }

    public boolean isReportEnabled() { return reportEnabled; }
    public void setReportEnabled(boolean v) { reportEnabled = v; }
    public boolean isConsentRequired() { return consentRequired; }
    public void setConsentRequired(boolean v) { consentRequired = v; }
    public String getServerPublicKey() { return serverPublicKey; }
    public void setServerPublicKey(String v) { serverPublicKey = v; }
    public String getEncryptionAlgorithm() { return encryptionAlgorithm; }
    public void setEncryptionAlgorithm(String v) { encryptionAlgorithm = v; }
    public int getScanSeconds() { return scanSeconds; }
    public void setScanSeconds(int v) { scanSeconds = v; }
    public int getMaxRetries() { return maxRetries; }
    public void setMaxRetries(int v) { maxRetries = v; }
    public long getRetryBaseDelay() { return retryBaseDelay; }
    public void setRetryBaseDelay(long v) { retryBaseDelay = v; }
    public long getRetryMaxDelay() { return retryMaxDelay; }
    public void setRetryMaxDelay(long v) { retryMaxDelay = v; }
    public long getReportInterval() { return reportInterval; }
    public void setReportInterval(long v) { reportInterval = v; }
    public int getInputSampleTicks() { return inputSampleTicks; }
    public void setInputSampleTicks(int v) { inputSampleTicks = v; }
    public int getMouseSampleWindow() { return mouseSampleWindow; }
    public void setMouseSampleWindow(int v) { mouseSampleWindow = v; }
    public boolean isReportJson() { return reportJson; }
    public void setReportJson(boolean v) { reportJson = v; }
    public boolean isReportModules() { return reportModules; }
    public void setReportModules(boolean v) { reportModules = v; }
    public boolean isReportClipboard() { return reportClipboard; }
    public void setReportClipboard(boolean v) { reportClipboard = v; }
    public boolean isReportExternalDlls() { return reportExternalDlls; }
    public void setReportExternalDlls(boolean v) { reportExternalDlls = v; }
    public boolean isReportProcessList() { return reportProcessList; }
    public void setReportProcessList(boolean v) { reportProcessList = v; }
    public boolean isLogDetections() { return logDetections; }
    public void setLogDetections(boolean v) { logDetections = v; }
    public boolean isScanPrefetch() { return scanPrefetch; }
    public void setScanPrefetch(boolean v) { scanPrefetch = v; }
    public boolean isScanRegistry() { return scanRegistry; }
    public void setScanRegistry(boolean v) { scanRegistry = v; }
    public boolean isScanWindows() { return scanWindows; }
    public void setScanWindows(boolean v) { scanWindows = v; }

    public static SSMonitorConfig load(Path path) {
        SSMonitorConfig config = new SSMonitorConfig(path);
        try {
            config.load();
        } catch (IOException e) {
            config.setReportEnabled(true);
            config.setConsentRequired(true);
            config.setEncryptionAlgorithm("NONE");
            config.setScanSeconds(300);
            config.setMaxRetries(5);
            config.setRetryBaseDelay(1000L);
            config.setRetryMaxDelay(30000L);
            config.setReportInterval(60000L);
            config.setInputSampleTicks(20);
            config.setMouseSampleWindow(10);
            config.setReportJson(true);
            config.setReportModules(true);
            config.setReportClipboard(true);
            config.setReportExternalDlls(true);
            config.setReportProcessList(true);
            config.setLogDetections(true);
            config.setScanPrefetch(true);
            config.setScanRegistry(true);
            config.setScanWindows(true);
        }
        return config;
    }

    private static boolean parseBoolean(Properties props, String key, boolean def) {
        String val = props.getProperty(key);
        if (val == null) return def;
        return Boolean.parseBoolean(val.trim());
    }

    private static int getInt(Properties props, String key, int def) {
        String val = props.getProperty(key);
        if (val == null) return def;
        try {
            return Integer.parseInt(val.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static long getLong(Properties props, String key, long def) {
        String val = props.getProperty(key);
        if (val == null) return def;
        try {
            return Long.parseLong(val.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static String getString(Properties props, String key, String def) {
        String val = props.getProperty(key);
        return val != null ? val.trim() : def;
    }
}
