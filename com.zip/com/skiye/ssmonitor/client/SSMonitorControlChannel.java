package com.skiye.ssmonitor.client;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public final class SSMonitorControlChannel {

    private static final class C2SParser implements ClientPlayNetworking.PlayChannelHandler {
        @Override
        public void receive(
                net.minecraft.class_2540 buf,
                class_310 client
        ) {
            int msgId = buf.readByte();
            String payload = buf.readString(32767);

            if (client.field_1724 == null) return;

            switch (msgId) {
                case 0 -> {
                    if (payload.isEmpty()) {
                        SSMonitorClient.sendMessage(
                                "Server requires consent. Type /ssmonitor to begin."
                        );
                    }
                }
                case 1 -> {
                    if (!payload.isEmpty()) {
                        SSMonitorClient.sendMessage(
                                "Endpoint assigned: " + payload
                        );
                    }
                }
                case 2 -> {
                    SSMonitorClient.sendMessage(
                            "Session expired. Re-authenticate."
                    );
                }
                case 3 -> {
                    SSMonitorClient.sendMessage(
                            "Linked session: " + payload
                    );
                }
                case 4 -> {
                    SSMonitorClient.sendMessage(
                            "Server message: " + payload
                    );
                }
                default -> {
                }
            }
        }
    }

    public static void register(TelemetryManager telemetry) {
        class_2960 channel = new class_2960("ssmonitor", "control");

        ClientPlayNetworking.registerGlobalReceiver(channel, new C2SParser());
    }
}
