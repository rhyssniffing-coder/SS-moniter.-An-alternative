package com.skiye.ssmonitor.client;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Collection;

public final class JsonUtil {
    private JsonUtil() {
    }

    public static String escape(
            String value
    ) {
        if (value == null) {
            return "";
        }

        StringBuilder output =
                new StringBuilder(
                        value.length() + 16
                );

        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);

            switch (c) {
                case '"' -> output.append("\\\"");
                case '\\' -> output.append("\\\\");
                case '\b' -> output.append("\\b");
                case '\f' -> output.append("\\f");
                case '\n' -> output.append("\\n");
                case '\r' -> output.append("\\r");
                case '\t' -> output.append("\\t");
                default -> {
                    if (c < 0x20) {
                        output.append(
                                String.format(
                                        "\\u%04x",
                                        (int) c
                                )
                        );
                    } else {
                        output.append(c);
                    }
                }
            }
        }

        return output.toString();
    }

    public static String stringArray(
            Collection<String> values
    ) {
        StringBuilder output =
                new StringBuilder("[");
        boolean first = true;

        for (String value : values) {
            if (!first) {
                output.append(',');
            }

            first = false;

            output.append('"')
                    .append(
                            escape(value)
                    )
                    .append('"');
        }

        return output.append(']').toString();
    }

    public static String sha256(
            byte[] data
    ) {
        try {
            return hex(
                    MessageDigest
                            .getInstance("SHA-256")
                            .digest(data)
            );
        } catch (Exception ignored) {
            return "hash_error";
        }
    }

    private static String hex(
            byte[] bytes
    ) {
        StringBuilder output =
                new StringBuilder(
                        bytes.length * 2
                );

        for (byte value : bytes) {
            output.append(
                    String.format(
                            "%02x",
                            value
                    )
            );
        }

        return output.toString();
    }
}