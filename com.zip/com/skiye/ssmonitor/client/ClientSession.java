package com.skiye.ssmonitor.client;

public record ClientSession(
        int protocol,
        String sessionId,
        String token,
        String endpoint
) {
    public boolean valid() {
        return protocol == 2 && !sessionId.isBlank() && !token.isBlank();
    }
}
