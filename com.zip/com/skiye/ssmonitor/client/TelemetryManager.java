package com.skiye.ssmonitor.client;

import com.google.gson.Gson;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5765;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicLong;
import java.util.zip.Deflater;

public final class TelemetryManager {

    private final SSMonitorConfig config;
    private final AtomicLong sequenceCounter;
    private final InputTracker inputTracker;
    private final BlockingQueue<String> outgoingQueue = new LinkedBlockingQueue<>();
    private final Gson gson = new Gson();

    private long lastInputX;
    private long lastInputY;
    private long lastLookX;
    private long lastLookY;
    private long currentInputX;
    private long currentInputY;
    private long currentLookX;
    private long currentLookY;
    private int clickCounter;
    private int lastClickCounter;

    private volatile boolean running;
    private volatile boolean hasSession;
    private volatile String pendingEndpoint;
    private volatile long sessionExpires;
    private volatile int consecutiveFailures;
    private volatile String lastFailure;
    private volatile boolean disconnected;
    private volatile String endpointUrl;

    private static final class FullReport implements Runnable {
        private final TelemetryManager mgr;
        private final String trigger;
        private final Path reportDir;
        private final Path reportFile;

        FullReport(TelemetryManager mgr, String trigger) {
            this.mgr = mgr;
            this.trigger = trigger;
            Path base = mgr.config.getConfigDir().resolve("reports");
            this.reportDir = base;
            this.reportFile = base.resolve("latest.json");
        }

        @Override
        public void run() {
            try {
                if (!mgr.hasSession) return;

                Files.createDirectories(reportDir);

                ExternalDllScanner.DllScanResult dllScan = null;
                if (mgr.config.isReportExternalDlls()) {
                    dllScan = ExternalDllScanner.scan();
                }

                boolean hasExtDll = dllScan != null;

                long now = Instant.now().toEpochMilli();
                long seq = mgr.sequenceCounter.incrementAndGet();

                String sessionId = "";
                try {
                    Path sessionFile = mgr.config.getConfigDir()
                            .resolve("session.id");
                    if (Files.exists(sessionFile)) {
                        sessionId = Files.readString(sessionFile).trim();
                    }
                } catch (Exception ignored) {
                }

                StringBuilder json = new StringBuilder();
                json.append("{");

                json.append("\"schema_version\":2,");
                json.append("\"mod_version\":\"")
                        .append(SSMonitorClient.VERSION).append("\",");
                json.append("\"protocol_version\":4,");
                json.append("\"session_id\":\"").append(sessionId).append("\",");
                json.append("\"sequence\":").append(seq).append(",");
                json.append("\"timestamp\":").append(now).append(",");
                json.append("\"expires_at\":")
                        .append(mgr.sessionExpires).append(",");

                json.append("\"trigger\":\"").append(trigger).append("\",");

                mgr.appendJvmReport(json);

                mgr.appendOpenModsReport(json);

                mgr.appendModuleReport(json);

                mgr.appendInputReport(json);

                mgr.appendClipboardReport(json);

                json.append("\"font_families\":[");
                mgr.appendFontFamilies(json);
                json.append("],");

                mgr.appendScreenReport(json);

                if (hasExtDll) {
                    json.append("\"external_scan\":{");
                    json.append("\"critical\":").append(dllScan.criticalCount()).append(",");
                    json.append("\"high\":").append(dllScan.highCount()).append(",");
                    json.append("\"medium\":").append(dllScan.mediumCount()).append(",");
                    json.append("\"findings\":");
                    json.append("[");
                    boolean first = true;
                    for (ExternalDllScanner.Finding f : dllScan.findings()) {
                        if (!first) json.append(",");
                        first = false;
                        json.append("{\"cat\":\"").append(esc(f.category()))
                                .append("\",\"name\":\"").append(esc(f.name()))
                                .append("\",\"sev\":\"").append(f.severity())
                                .append("\",\"detail\":\"").append(esc(f.detail()))
                                .append("\"}");
                    }
                    json.append("],");
                    json.append("\"running_injectors\":[");
                    appendStringArray(json, dllScan.runningInjectors());
                    json.append("],");
                    json.append("\"suspicious_processes\":[");
                    appendStringArray(json, dllScan.suspiciousProcesses());
                    json.append("],");
                    json.append("\"suspicious_modules\":[");
                    appendStringArray(json, dllScan.suspiciousModules());
                    json.append("],");
                    json.append("\"unknown_jvm_args\":[");
                    appendStringArray(json, dllScan.unknownJvmArgs());
                    json.append("],");
                    json.append("\"has_java_agents\":")
                            .append(dllScan.hasJavaAgents()).append(",");
                    json.append("\"agent_paths\":[");
                    appendStringArray(json, dllScan.agentPaths());
                    json.append("],");
                    json.append("\"cheat_mods\":[");
                    appendStringArray(json, dllScan.cheatMods());
                    json.append("],");
                    json.append("\"prefetch_matches\":[");
                    appendStringArray(json, dllScan.prefetchMatches());
                    json.append("],");
                    json.append("\"amcache_hits\":[");
                    appendStringArray(json, dllScan.amcacheHits());
                    json.append("],");
                    json.append("\"bam_entries\":[");
                    appendStringArray(json, dllScan.bamEntries());
                    json.append("],");
                    json.append("\"shim_cache_hits\":[");
                    appendStringArray(json, dllScan.shimCacheHits());
                    json.append("],");
                    json.append("\"hook_detections\":[");
                    appendStringArray(json, dllScan.hookDetections());
                    json.append("],");
                    json.append("\"window_titles\":[");
                    appendStringArray(json, dllScan.windowTitles());
                    json.append("],");
                    json.append("\"suspicious_services\":[");
                    appendStringArray(json, dllScan.suspiciousServices());
                    json.append("],");
                    json.append("\"anti_debug_detected\":")
                            .append(dllScan.antiDebugDetected());
                    json.append("},");
                }

                mgr.appendSessionReport(json);

                json.append("\"integrity_passed\":true,");
                json.append("\"consent_verified\":true,");
                json.append("\"client_hwid\":\"\"}");

                String payload = json.toString();
                Files.writeString(reportFile, payload, StandardCharsets.UTF_8);

                mgr.enqueueReport(payload);

                mgr.consecutiveFailures = 0;

            } catch (Exception e) {
                mgr.lastFailure = e.getClass().getSimpleName()
                        + ": " + e.getMessage();
                mgr.consecutiveFailures++;
            }
        }
    }

    public TelemetryManager(
            SSMonitorConfig config,
            AtomicLong sequenceCounter,
            InputTracker inputTracker
    ) {
        this.config = config;
        this.sequenceCounter = sequenceCounter;
        this.inputTracker = inputTracker;
        this.consecutiveFailures = 0;
    }

    public void onServerJoin(class_310 client) {
        disconnected = false;
        hasSession = false;

        try {
            Path sessionFile = config.getConfigDir().resolve("session.id");
            if (Files.exists(sessionFile)) {
                String sessionId = Files.readString(sessionFile).trim();
                if (!sessionId.isEmpty()) {
                    hasSession = true;
                    sessionExpires = Instant.now().plusSeconds(86400).toEpochMilli();
                }
            }
        } catch (Exception ignored) {
        }

        if (config.isReportEnabled() && hasSession) {
            running = true;
            SSMonitorClient.sendMessage("Session active. Telemetry enabled.");
        }
    }

    public void onServerDisconnect() {
        disconnected = true;
        running = false;
        hasSession = false;
        outgoingQueue.clear();
    }

    public void sendFullReport(class_310 client, String trigger) {
        if (!running || disconnected || !hasSession) return;
        new Thread(new FullReport(this, trigger), "ssmonitor-report").start();
    }

    public void processInput(class_310 client) {
        if (!running) return;
        inputTracker.sample(client);
    }

    public void processScreenState(class_310 client) {
        if (!running || client.field_1724 == null) return;
    }

    public void processClickTiming() {
        if (!running) return;
        clickCounter = inputTracker.getClickCount();
    }

    public boolean isRunning() {
        return running;
    }

    public int getQueueSize() {
        return outgoingQueue.size();
    }

    public int getConsecutiveFailures() {
        return consecutiveFailures;
    }

    public boolean hasSession() {
        return hasSession;
    }

    public String getEndpointStatus() {
        return endpointUrl != null ? endpointUrl : "NONE";
    }

    public String getLastFailure() {
        return lastFailure != null ? lastFailure : "NONE";
    }

    public void registerEndpoint(String url, long expiresAt) {
        this.endpointUrl = url;
        this.sessionExpires = expiresAt;
        this.hasSession = true;
    }

    private void enqueueReport(String json) {
        outgoingQueue.offer(json);
        drainQueue();
    }

    private void drainQueue() {
        while (!outgoingQueue.isEmpty()) {
            String payload = outgoingQueue.peek();
            if (payload == null) break;

            try {
                byte[] raw = payload.getBytes(StandardCharsets.UTF_8);

                Deflater deflater = new Deflater();
                deflater.setInput(raw);
                deflater.finish();
                byte[] buffer = new byte[raw.length + 128];
                int compressedSize = deflater.deflate(buffer);
                deflater.end();
                byte[] compressed = new byte[compressedSize];
                System.arraycopy(buffer, 0, compressed, 0, compressedSize);

                String endpoint = endpointUrl;
                if (endpoint == null || endpoint.isEmpty()) {
                    return;
                }

                Path keyPath = config.getConfigDir().resolve("server.pub");

                class_2960 url = new class_2960(endpoint);

                byte[] fullBody = new byte[4 + compressed.length];
                fullBody[0] = (byte) 4;
                fullBody[1] = (byte) 2;
                fullBody[2] = (byte) ((compressed.length >> 8) & 0xFF);
                fullBody[3] = (byte) (compressed.length & 0xFF);
                System.arraycopy(compressed, 0, fullBody, 4, compressed.length);

                ClientPlayNetworking.send(url,
                        new class_5765(fullBody, 0, fullBody.length));

                outgoingQueue.poll();
                consecutiveFailures = 0;

            } catch (Exception e) {
                lastFailure = e.getClass().getSimpleName()
                        + ": " + e.getMessage();
                consecutiveFailures++;
                break;
            }
        }
    }

    private void appendJvmReport(StringBuilder json) {
        RuntimeMXBean runtime = ManagementFactory.getRuntimeMXBean();
        Runtime runtimeTotal = Runtime.getRuntime();

        json.append("\"jvm\":{");
        json.append("\"max_memory\":").append(runtimeTotal.maxMemory()).append(",");
        json.append("\"total_memory\":").append(runtimeTotal.totalMemory()).append(",");
        json.append("\"free_memory\":").append(runtimeTotal.freeMemory()).append(",");
        json.append("\"available_processors\":")
                .append(runtimeTotal.availableProcessors()).append(",");
        json.append("\"uptime_ms\":").append(runtime.getUptime()).append(",");
        json.append("\"vm_name\":\"")
                .append(esc(runtime.getVmName())).append("\",");
        json.append("\"vm_version\":\"")
                .append(esc(runtime.getVmVersion())).append("\",");
        json.append("\"java_version\":\"")
                .append(esc(runtime.getSpecVersion())).append("\"");

        if (config.isReportModules()) {
            List<String> args = runtime.getInputArguments();
            json.append(",\"input_arguments\":[");
            for (int i = 0; i < args.size(); i++) {
                if (i > 0) json.append(",");
                json.append("\"").append(esc(args.get(i))).append("\"");
            }
            json.append("]");
        }

        json.append("},");
    }

    private void appendOpenModsReport(StringBuilder json) {
        json.append("\"open_mods\":{");

        try {
            java.lang.reflect.Field factoryField = null;
            try {
                factoryField = Class.forName(
                        "net.fabricmc.loader.impl.FabricLoaderImpl"
                ).getDeclaredField("modContainerFactory");
            } catch (Exception ignored) {
            }

            Class<?> klass = Class.forName(
                    "net.fabricmc.loader.impl.FabricLoaderImpl"
            );
            java.lang.reflect.Method getInstance = klass.getDeclaredMethod("getInstance");
            Object instance = getInstance.invoke(null);

            java.lang.reflect.Method getMods = klass.getDeclaredMethod("getMods");
            Iterable<?> mods = (Iterable<?>) getMods.invoke(instance);

            boolean first = true;
            for (Object mod : mods) {
                Class<?> modContainer = Class.forName(
                        "net.fabricmc.loader.api.metadata.ModContainer"
                );
                if (!modContainer.isInstance(mod)) continue;

                Object metadata = mod.getClass().getMethod("getMetadata").invoke(mod);
                Object modId = metadata.getClass().getMethod("getId").invoke(metadata);
                Object version = metadata.getClass().getMethod("getVersion").invoke(metadata);

                if (modId.toString().equals("fabricloader")
                        || modId.toString().equals("java")) continue;

                if (!first) json.append(",");
                first = false;
                json.append("\"").append(esc(modId.toString()))
                        .append("\":\"")
                        .append(esc(version.toString())).append("\"");
            }
        } catch (Exception e) {
            json.append("\"error\":\"")
                    .append(esc(e.getMessage())).append("\"");
        }

        json.append("},");
    }

    private void appendModuleReport(StringBuilder json) {
        json.append("\"loaded_modules\":{");

        try {
            var modules = java.lang.ModuleLayer.boot().modules();
            boolean first = true;
            for (var mod : modules) {
                if (mod.getName().startsWith("java.") || mod.getName().startsWith("jdk.")) continue;
                if (mod.getName().startsWith("sun.")) continue;
                if (mod.getName().startsWith("jdk.internal.")) continue;

                if (!first) json.append(",");
                first = false;
                json.append("\"").append(esc(mod.getName())).append("\":\"")
                        .append(esc(mod.getName())).append("\"");
            }
        } catch (Exception e) {
            json.append("\"error\":\"")
                    .append(esc(e.getMessage())).append("\"");
        }

        json.append("},");
    }

    private void appendInputReport(StringBuilder json) {
        if (config.getInputSampleTicks() > 0) {
            json.append("\"input_sample\":{");
            json.append("\"delta_x\":").append(currentInputX).append(",");
            json.append("\"delta_y\":").append(currentInputY).append(",");
            json.append("\"look_delta_x\":").append(currentLookX).append(",");
            json.append("\"look_delta_y\":").append(currentLookY);
            json.append("},");
        }

        long now = System.currentTimeMillis();
        long clickDelta = clickCounter - lastClickCounter;
        if (clickDelta > 0) {
            json.append("\"click_cps\":").append(clickDelta).append(",");
            lastClickCounter = clickCounter;
        }
    }

    private void appendClipboardReport(StringBuilder json) {
        if (!config.isReportClipboard()) return;

        try {
            java.awt.datatransfer.Clipboard clipboard =
                    Toolkit.getDefaultToolkit().getSystemClipboard();
            Transferable contents = clipboard.getContents(null);
            if (contents != null && contents.isDataFlavorSupported(
                    DataFlavor.stringFlavor)) {
                String text = (String) contents.getTransferData(
                        DataFlavor.stringFlavor
                );
                if (text != null && !text.isEmpty()) {
                    json.append("\"clipboard\":{");
                    json.append("\"length\":").append(text.length());
                    json.append("},");
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void appendFontFamilies(StringBuilder json) {
        try {
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            String[] families = ge.getAvailableFontFamilyNames();
            for (int i = 0; i < Math.min(families.length, 10); i++) {
                if (i > 0) json.append(",");
                json.append("\"").append(esc(families[i])).append("\"");
            }
        } catch (Exception e) {
            json.append("\"error\"");
        }
    }

    private void appendScreenReport(StringBuilder json) {
        try {
            var displays = class_310.method_1551().field_1773.method_43449();
            json.append("\"displays\":{");
            json.append("\"count\":").append(displays.size());
            json.append("},");
        } catch (Exception e) {
            json.append("\"displays\":{\"error\":\"").append(esc(e.getMessage())).append("\"},");
        }

        try {
            var guiScale = class_310.method_1551().field_1773.method_43441();
            json.append("\"gui_scale\":").append(guiScale).append(",");
        } catch (Exception e) {
            json.append("\"gui_scale\":0,");
        }
    }

    private void appendSessionReport(StringBuilder json) {
        try {
            Path keyPath = config.getConfigDir().resolve("server.pub");
            if (Files.exists(keyPath)) {
                String pubKeyStr = Files.readString(keyPath).trim();
                json.append("\"public_key_hash\":\"")
                        .append(esc(pubKeyStr)).append("\",");
            }
        } catch (Exception ignored) {
        }

        try {
            Path endpointPath = config.getConfigDir().resolve("endpoint.url");
            if (Files.exists(endpointPath)) {
                String endpoint = Files.readString(endpointPath).trim();
                json.append("\"endpoint\":\"")
                        .append(esc(endpoint)).append("\",");
            }
        } catch (Exception ignored) {
        }
    }

    private static void appendStringArray(StringBuilder json, List<String> list) {
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) json.append(",");
            json.append("\"").append(esc(list.get(i))).append("\"");
        }
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}
