package com.skiye.ssmonitor.client;

import java.nio.charset.StandardCharsets;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record SSMonitorControlPayload(String json) implements class_8710 {
    private static final int MAX_BYTES = 32_000;

    public static final class_8710.class_9154<SSMonitorControlPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(SSMonitorClient.MOD_ID, "control"));
    public static final class_9139<class_9129, SSMonitorControlPayload> CODEC =
            class_9139.method_56438(SSMonitorControlPayload::encode, SSMonitorControlPayload::decode);

    @Override
    public class_8710.class_9154<SSMonitorControlPayload> method_56479() {
        return ID;
    }

    private static void encode(
            SSMonitorControlPayload payload,
            class_9129 buffer
    ) {
        byte[] bytes = payload.json().getBytes(StandardCharsets.UTF_8);

        if (bytes.length > MAX_BYTES) {
            throw new IllegalArgumentException("SS Monitor control payload exceeds 32 KB");
        }

        buffer.method_52983(bytes);
    }

    private static SSMonitorControlPayload decode(
            class_9129 buffer
    ) {
        int length = buffer.readableBytes();

        if (length > MAX_BYTES) {
            throw new IllegalArgumentException("SS Monitor control payload exceeds 32 KB");
        }

        byte[] bytes = new byte[length];
        buffer.method_52979(bytes);

        return new SSMonitorControlPayload(
                new String(bytes, StandardCharsets.UTF_8)
        );
    }
}
