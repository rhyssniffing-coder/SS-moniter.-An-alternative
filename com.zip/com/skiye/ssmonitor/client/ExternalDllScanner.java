package com.skiye.ssmonitor.client;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class ExternalDllScanner {

    public enum Severity {
        CRITICAL,
        HIGH,
        MEDIUM,
        LOW,
        INFO
    }

    public record Finding(
            String category,
            String name,
            Severity severity,
            String detail
    ) {
    }

    public record DllScanResult(
            List<Finding> findings,
            List<String> runningInjectors,
            List<String> suspiciousProcesses,
            List<String> suspiciousModules,
            List<String> unknownJvmArgs,
            boolean hasJavaAgents,
            List<String> agentPaths,
            List<String> cheatMods,
            List<String> prefetchMatches,
            List<String> amcacheHits,
            List<String> bamEntries,
            List<String> shimCacheHits,
            List<String> hookDetections,
            List<String> windowTitles,
            List<String> suspiciousServices,
            boolean antiDebugDetected,
            int criticalCount,
            int highCount,
            int mediumCount
    ) {
    }

    private static final Set<String> KNOWN_INJECTORS = Set.of(
            "xenos.exe", "xenos64.exe",
            "extreme injector.exe", "extreme injector v3.exe",
            "process hacker.exe", "processhacker.exe",
            "process hacker 3.exe", "processhacker3.exe",
            "cheat engine.exe", "cheatengine.exe",
            "injector.exe", "dllinjector.exe",
            "gh_dragon.exe", "hanstamco.exe",
            "synapse.injector.exe",
            "cecile.exe",
            "scylla.exe", "scyllahide.exe",
            "megadumper.exe",
            "httpdebuggerpro.exe",
            "dnspy.exe", "dnspy.exe",
            "ollydbg.exe", "x64dbg.exe", "x32dbg.exe",
            "ida.exe", "ida64.exe",
            "reclass.net.exe", "reclassnet.exe",
            "openedition.exe",
            "cheatengine-i386.exe", "cheatengine-x86_64.exe",
            "ollyice.exe", "devenv.exe"
    );

    private static final Set<String> KNOWN_LAUNCHER_PROCESSES = Set.of(
            "prestige launcher.exe", "prestige.exe",
            "novo.exe", "rockclient.exe",
            "lunar.exe", "badlion.exe",
            "feather.exe", "essential.exe",
            "e4mc.exe", "sketchup.exe",
            "salwyrr.exe", "labymod.exe"
    );

    private static final Set<String> KNOWN_CHEAT_PROCESSES = Set.of(
            "prestige launcher.exe", "prestige.exe",
            "novo.exe", "rockclient.exe",
            "grim.exe", "grim-client.exe",
            "vape.exe", "vape-lite.exe", "vape4.exe",
            "karhu.exe", "red.exe",
            "photon.exe", "aurora.exe",
            "moonlight.exe", "luminosity.exe",
            "metamorph.exe", "surgence.exe",
            "客户端.exe", "horion.exe",
            "zephyr.exe", "nova.exe",
            "kronk.exe", "rise.exe",
            "sigma.exe", "wurst.exe",
            "impact.exe", "future.exe",
            "aristois.exe", "meteor.exe",
            "inertia.exe", "ambience.exe",
            "bleachhack.exe", "meteor-client.exe",
            "argon.exe", "crescent.exe",
            "sigma-client.exe"
    );

    private static final Set<String> KNOWN_SUSPICIOUS_DLLS = Set.of(
            "renderhook.dll", "overlay.dll",
            "injected.dll", "cheat.dll", "hack.dll",
            "external.dll", "capture.dll", "mirror.dll",
            "hook.dll", "detours.dll", "minhook.dll",
            "trampoline.dll", "easyhook.dll", "sigscan.dll",
            "authlib.dll", "offline.dll",
            "prestige.dll", "stage2.dll",
            "module.dll", "payload.dll",
            "d3dhook.dll", "dxcapture.dll",
            "framedelay.dll", "renderoverlay.dll",
            "glhook.dll", "openglhook.dll",
            "nshook.dll", "nwjs.dll"
    );

    private static final Set<String> CHEAT_MOD_SIGNATURES = Set.of(
            "offline-client-bootstrap",
            "offlineclientbootstrap",
            "ChildFirstClassLoader",
            "OfflinePreLaunch",
            "OfflineIdentityOverride",
            "OfflineNetworkPolicy",
            "OfflineClientInit",
            "tru3club",
            "rockclient",
            "prestige",
            "novo",
            "grim",
            "vape",
            "karhu",
            "horion",
            "zephyr",
            "meteor",
            "inertia",
            "wurst",
            "impact",
            "future",
            "aristois",
            "bleachhack",
            "argon",
            "crescent",
            "sigma",
            "ambience",
            "luminosity",
            "moonlight",
            "surgence"
    );

    private static final String[] SUSPICIOUS_SERVICES = {
            "cheatengine", "xenos", "extremeinjector",
            "processhacker", "scylla", "cecile",
            "synapse", "injection", "inject"
    };

    private static final String[] SUSPICIOUS_WINDOW_KEYWORDS = {
            "cheat", "hack", "inject", "overlay",
            "debug", "hook", "dump", "extract",
            "reclass", "scanner", "trainer",
            "vape", "karhu", "wurst", "impact",
            "meteor", "horion", "zephyr", "aristois",
            "prestige", "grim"
    };

    public static DllScanResult scan() {
        List<Finding> findings = new ArrayList<>();

        scanProcesses(findings);
        scanJvmModules(findings);
        scanJvmArgs(findings);
        scanJavaAgents(findings);
        scanCheatMods(findings);
        scanPrefetch(findings);
        scanAmcache(findings);
        scanBam(findings);
        scanShimCache(findings);
        scanHooks(findings);
        scanWindows(findings);
        scanServices(findings);
        scanAntiDebug(findings);

        List<String> injectors = new ArrayList<>();
        List<String> procs = new ArrayList<>();
        List<String> modules = new ArrayList<>();
        List<String> unknownArgs = new ArrayList<>();
        List<String> agents = new ArrayList<>();
        List<String> cheatMods = new ArrayList<>();
        List<String> prefetch = new ArrayList<>();
        List<String> amcache = new ArrayList<>();
        List<String> bam = new ArrayList<>();
        List<String> shim = new ArrayList<>();
        List<String> hooks = new ArrayList<>();
        List<String> windows = new ArrayList<>();
        List<String> services = new ArrayList<>();
        boolean antiDebug = false;
        int critical = 0, high = 0, medium = 0;

        for (Finding f : findings) {
            switch (f.category()) {
                case "injector" -> injectors.add(f.name());
                case "process" -> procs.add(f.name());
                case "module" -> modules.add(f.detail());
                case "jvm_arg" -> unknownArgs.add(f.detail());
                case "agent" -> agents.add(f.detail());
                case "cheat_mod" -> cheatMods.add(f.detail());
                case "prefetch" -> prefetch.add(f.detail());
                case "amcache" -> amcache.add(f.detail());
                case "bam" -> bam.add(f.detail());
                case "shim" -> shim.add(f.detail());
                case "hook" -> hooks.add(f.detail());
                case "window" -> windows.add(f.detail());
                case "service" -> services.add(f.detail());
                case "anti_debug" -> antiDebug = true;
            }
            if (f.severity() == Severity.CRITICAL) critical++;
            else if (f.severity() == Severity.HIGH) high++;
            else if (f.severity() == Severity.MEDIUM) medium++;
        }

        boolean foundAnything = !findings.isEmpty()
                && findings.stream().anyMatch(
                f -> f.severity() == Severity.CRITICAL
                        || f.severity() == Severity.HIGH
                        || f.severity() == Severity.MEDIUM
        );

        if (foundAnything) {
            StringBuilder msg = new StringBuilder();
            msg.append("C:").append(critical)
                    .append(" H:").append(high)
                    .append(" M:").append(medium);
            SSMonitorClient.sendMessage("Findings " + msg);

            SSMonitorConfig cfg = SSMonitorClient.getInstance() != null
                    ? SSMonitorClient.getInstance().getConfig()
                    : null;
            if (cfg != null) {
                StringBuilder logDetail = new StringBuilder();
                for (Finding f : findings) {
                    if (f.severity() == Severity.CRITICAL
                            || f.severity() == Severity.HIGH) {
                        logDetail.append("[").append(f.severity())
                                .append("] ").append(f.category())
                                .append(": ").append(f.name());
                        if (!f.detail().isEmpty()) {
                            logDetail.append(" (").append(f.detail()).append(")");
                        }
                        logDetail.append("\n");
                    }
                }
                cfg.writeDetectionLog("system_scan", logDetail.toString());
            }
        }

        return new DllScanResult(
                findings,
                injectors,
                procs,
                modules,
                unknownArgs,
                !agents.isEmpty(),
                agents,
                cheatMods,
                prefetch,
                amcache,
                bam,
                shim,
                hooks,
                windows,
                services,
                antiDebug,
                critical,
                high,
                medium
        );
    }

    private static void scanProcesses(List<Finding> findings) {
        if (!isWindows()) return;

        try {
            Process process = Runtime.getRuntime().exec(
                    new String[]{"tasklist", "/FO", "CSV", "/NH"}
            );
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream())
            )) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String lower = line.toLowerCase();
                    String pname = extractCsvField(line, 0);
                    if (pname.isEmpty()) continue;

                    for (String inj : KNOWN_INJECTORS) {
                        if (lower.contains(inj)) {
                            findings.add(new Finding(
                                    "injector", pname,
                                    Severity.CRITICAL,
                                    "Known injector running"
                            ));
                        }
                    }
                    for (String cheat : KNOWN_CHEAT_PROCESSES) {
                        if (lower.contains(cheat)) {
                            findings.add(new Finding(
                                    "process", pname,
                                    Severity.HIGH,
                                    "Known cheat process"
                            ));
                        }
                    }
                    for (String launch : KNOWN_LAUNCHER_PROCESSES) {
                        if (lower.contains(launch)) {
                            findings.add(new Finding(
                                    "process", pname,
                                    Severity.MEDIUM,
                                    "Known third-party launcher"
                            ));
                        }
                    }
                    if (lower.contains("inject")
                            || lower.contains("cheat")
                            || lower.contains("hack")
                            || lower.contains("dump")
                            || lower.contains("extract")
                            || lower.contains("debug")
                            || lower.contains("hook")) {
                        if (!pname.equals("java.exe")
                                && !pname.equals("javaw.exe")
                                && !pname.equals("svchost.exe")
                                && !pname.equals("csrss.exe")) {
                            findings.add(new Finding(
                                    "process", pname,
                                    Severity.MEDIUM,
                                    "Suspicious keyword in process name"
                            ));
                        }
                    }
                }
            }
            process.waitFor();
        } catch (Exception ignored) {
        }
    }

    private static void scanJvmModules(List<Finding> findings) {
        RuntimeMXBean runtime = ManagementFactory.getRuntimeMXBean();

        for (String arg : runtime.getInputArguments()) {
            if (arg.startsWith("-javaagent:")
                    || arg.startsWith("-agentlib:")
                    || arg.startsWith("-agentpath:")) {
                String value = arg.contains(":")
                        ? arg.substring(arg.indexOf(':') + 1)
                        : arg;
                String lower = value.toLowerCase();

                for (String dll : KNOWN_SUSPICIOUS_DLLS) {
                    if (lower.contains(dll)) {
                        findings.add(new Finding(
                                "module", "suspicious_agent",
                                Severity.HIGH,
                                "Suspicious agent: " + value
                        ));
                        break;
                    }
                }

                if (!isKnownAgent(value) && !isVanillaAgent(value)) {
                    findings.add(new Finding(
                            "agent", "unknown_agent",
                            Severity.MEDIUM,
                            "Unknown Java agent: " + value
                    ));
                }
            }
        }
    }

    private static void scanJvmArgs(List<Finding> findings) {
        RuntimeMXBean runtime = ManagementFactory.getRuntimeMXBean();

        for (String arg : runtime.getInputArguments()) {
            String lower = arg.toLowerCase();
            if (lower.contains("jdwp") || lower.contains("suspend=n")) {
                findings.add(new Finding(
                        "anti_debug", "jdwp_debug",
                        Severity.HIGH,
                        "JDWP debug agent detected: " + arg
                ));
            }
            if (lower.contains("-xx:flags")) {
                findings.add(new Finding(
                        "jvm_arg", "custom_flags",
                        Severity.LOW,
                        "Custom JVM flags: " + arg
                ));
            }
        }
    }

    private static void scanJavaAgents(List<Finding> findings) {
        RuntimeMXBean runtime = ManagementFactory.getRuntimeMXBean();

        for (String arg : runtime.getInputArguments()) {
            if (arg.startsWith("-javaagent:")) {
                String path = arg.substring("-javaagent:".length());
                if (!isKnownAgent(path)) {
                    findings.add(new Finding(
                            "agent", "unknown_agent",
                            Severity.MEDIUM,
                            "Unknown agent loaded: " + path
                    ));
                }
            }
        }
    }

    private static void scanCheatMods(List<Finding> findings) {
        String mcDir = System.getProperty("user.home")
                + File.separator + "AppData" + File.separator
                + "Roaming" + File.separator + ".minecraft";

        String[] scanDirs = {
                mcDir + File.separator + "mods",
                mcDir + File.separator + "versions",
                mcDir + File.separator + ".fabric",
                mcDir + File.separator + "libraries"
        };

        for (String dirPath : scanDirs) {
            File dir = new File(dirPath);
            if (!dir.exists()) continue;
            scanDirForMods(dir, findings, 0);
        }
    }

    private static void scanDirForMods(
            File dir, List<Finding> findings, int depth
    ) {
        if (depth > 5 || findings.size() > 50) return;

        File[] files = dir.listFiles();
        if (files == null) return;

        for (File file : files) {
            if (file.isFile()
                    && file.getName().toLowerCase().endsWith(".jar")) {
                try {
                    java.util.jar.JarFile jar =
                            new java.util.jar.JarFile(file.toFile());
                    java.util.Enumeration<java.util.jar.JarEntry> en =
                            jar.entries();
                    while (en.hasMoreElements()) {
                        String entry = en.nextElement().getName();
                        String lower = entry.toLowerCase();
                        for (String sig : CHEAT_MOD_SIGNATURES) {
                            if (lower.contains(sig.toLowerCase())) {
                                String detail = file.getName()
                                        + ":" + entry;
                                boolean alreadyFound = findings.stream()
                                        .anyMatch(f -> f.detail().contains(detail));
                                if (!alreadyFound) {
                                    Severity sev = Severity.HIGH;
                                    if (lower.contains("prestige")
                                            || lower.contains("offline")
                                            || lower.contains("vape")
                                            || lower.contains("wurst")) {
                                        sev = Severity.CRITICAL;
                                    }
                                    findings.add(new Finding(
                                            "cheat_mod", sig,
                                            sev,
                                            detail
                                    ));
                                }
                            }
                        }
                    }
                    jar.close();
                } catch (Exception ignored) {
                }
            } else if (file.isDirectory()) {
                scanDirForMods(file, findings, depth + 1);
            }
        }
    }

    private static void scanPrefetch(List<Finding> findings) {
        if (!isWindows()) return;

        File prefetchDir = new File("C:\\Windows\\Prefetch");
        if (!prefetchDir.exists() || !prefetchDir.isDirectory()) return;

        File[] files = prefetchDir.listFiles();
        if (files == null) return;

        Set<String> allCheatNames = new HashSet<>();
        allCheatNames.addAll(KNOWN_INJECTORS);
        allCheatNames.addAll(KNOWN_CHEAT_PROCESSES);
        allCheatNames.addAll(KNOWN_LAUNCHER_PROCESSES);

        for (String cheat : allCheatNames) {
            String baseName = cheat.replace(".exe", "").toUpperCase()
                    .replace(" ", "_");
            for (File file : files) {
                String upper = file.getName().toUpperCase();
                if (upper.startsWith(baseName)
                        && upper.endsWith(".PF")) {
                    findings.add(new Finding(
                            "prefetch", cheat,
                            Severity.HIGH,
                            file.getName()
                    ));
                }
            }
        }

        String[] extraPatterns = {
                "PRESTIGE", "XENOS", "EXTREME_INJECTOR",
                "CHEAT_ENGINE", "PROCESS_HACKER",
                "CECILE", "SCYLLA", "SYNAPSE",
                "VAPE", "WURST", "HORION",
                "METEOR", "INERTIA", "IMPACT",
                "KARHU", "GRIM"
        };
        for (String pattern : extraPatterns) {
            for (File file : files) {
                String upper = file.getName().toUpperCase();
                if (upper.contains(pattern) && upper.endsWith(".PF")) {
                    boolean alreadyFound = findings.stream()
                            .anyMatch(f -> f.detail()
                                    .equals(file.getName()));
                    if (!alreadyFound) {
                        findings.add(new Finding(
                                "prefetch", pattern,
                                Severity.MEDIUM,
                                file.getName()
                        ));
                    }
                }
            }
        }
    }

    private static void scanAmcache(List<Finding> findings) {
        if (!isWindows()) return;

        try {
            Process proc = Runtime.getRuntime().exec(new String[]{
                    "reg", "query",
                    "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Appx\\Store\\Packages",
                    "/s", "/f", ".exe", "/d", "/c"
            });
            parseRegOutput(proc, "amcache", findings);
            proc.waitFor();
        } catch (Exception ignored) {
        }

        try {
            Process proc = Runtime.getRuntime().exec(new String[]{
                    "reg", "query",
                    "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatCache",
                    "/s", "/f", "xenos", "/d", "/c"
            });
            parseRegOutput(proc, "amcache", findings);
            proc.waitFor();
        } catch (Exception ignored) {
        }

        try {
            Process proc = Runtime.getRuntime().exec(new String[]{
                    "reg", "query",
                    "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatCache",
                    "/s", "/f", "cheat", "/d", "/c"
            });
            parseRegOutput(proc, "amcache", findings);
            proc.waitFor();
        } catch (Exception ignored) {
        }
    }

    private static void scanBam(List<Finding> findings) {
        if (!isWindows()) return;

        try {
            Process proc = Runtime.getRuntime().exec(new String[]{
                    "reg", "query",
                    "HKCU\\Environment",
                    "/v", "PATH"
            });
            proc.waitFor();
        } catch (Exception ignored) {
        }

        String[] bamKeys = {
                "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\BackgroundAccessApplications",
                "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\BackgroundAccessApplications"
        };

        Set<String> cheatNames = new HashSet<>();
        cheatNames.addAll(KNOWN_INJECTORS);
        cheatNames.addAll(KNOWN_CHEAT_PROCESSES);

        for (String key : bamKeys) {
            for (String cheat : cheatNames) {
                try {
                    Process proc = Runtime.getRuntime().exec(new String[]{
                            "reg", "query", key,
                            "/f", cheat.replace(".exe", ""),
                            "/s", "/c"
                    });
                    parseRegOutput(proc, "bam", findings);
                    proc.waitFor();
                } catch (Exception ignored) {
                }
            }
        }
    }

    private static void scanShimCache(List<Finding> findings) {
        if (!isWindows()) return;

        Set<String> cheatNames = new HashSet<>();
        cheatNames.addAll(KNOWN_INJECTORS);
        cheatNames.addAll(KNOWN_CHEAT_PROCESSES);

        for (String cheat : cheatNames) {
            try {
                Process proc = Runtime.getRuntime().exec(new String[]{
                        "reg", "query",
                        "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\AppCompatCache",
                        "/f", cheat.replace(".exe", ""),
                        "/s", "/c"
                });
                parseRegOutput(proc, "shim", findings);
                proc.waitFor();
            } catch (Exception ignored) {
            }
        }
    }

    private static void scanHooks(List<Finding> findings) {
        if (!isWindows()) return;

        try {
            Process proc = Runtime.getRuntime().exec(new String[]{
                    "tasklist", "/M", "/FI", "IMAGENAME eq javaw.exe"
            });
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(proc.getInputStream())
            )) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String lower = line.toLowerCase();
                    if (lower.contains("javaw.exe")) {
                        String[] parts = line.split("\\s+");
                        if (parts.length > 4) {
                            int moduleCount = parts.length - 4;
                            if (moduleCount > 30) {
                                findings.add(new Finding(
                                        "hook", "excessive_modules",
                                        Severity.HIGH,
                                        "javaw.exe loaded " + moduleCount
                                                + " modules (normal: <20)"
                                ));
                            }
                        }
                    }
                }
            }
            proc.waitFor();
        } catch (Exception ignored) {
        }

        try {
            Process proc = Runtime.getRuntime().exec(new String[]{
                    "wmic", "process", "where",
                    "name='javaw.exe'",
                    "get", "CommandLine", "/FORMAT:LIST"
            });
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(proc.getInputStream())
            )) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String lower = line.toLowerCase();
                    if (lower.contains("javaagent:")
                            || lower.contains("jdwp")) {
                        findings.add(new Finding(
                                "hook", "agent_in_cmdline",
                                Severity.HIGH,
                                "Agent/debug arg in javaw cmdline: " + line.trim()
                        ));
                    }
                }
            }
            proc.waitFor();
        } catch (Exception ignored) {
        }
    }

    private static void scanWindows(List<Finding> findings) {
        if (!isWindows()) return;

        try {
            Process proc = Runtime.getRuntime().exec(new String[]{
                    "powershell", "-Command",
                    "Get-Process | Where-Object {$_.MainWindowTitle -ne ''} | " +
                            "Select-Object ProcessName,MainWindowTitle | Format-List"
            });
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(proc.getInputStream())
            )) {
                String procName = "";
                String title = "";
                String line;
                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    if (line.startsWith("ProcessName")) {
                        procName = line.substring(
                                line.indexOf(':') + 1
                        ).trim().toLowerCase();
                    } else if (line.startsWith("MainWindowTitle")) {
                        title = line.substring(
                                line.indexOf(':') + 1
                        ).trim();
                        if (!title.isEmpty() && !procName.isEmpty()) {
                            String combined = procName + " " + title.toLowerCase();
                            for (String kw : SUSPICIOUS_WINDOW_KEYWORDS) {
                                if (combined.contains(kw)) {
                                    findings.add(new Finding(
                                            "window", procName,
                                            Severity.MEDIUM,
                                            "Suspicious window: [" + procName
                                                    + "] " + title
                                    ));
                                }
                            }
                        }
                    }
                }
            }
            proc.waitFor();
        } catch (Exception ignored) {
        }
    }

    private static void scanServices(List<Finding> findings) {
        if (!isWindows()) return;

        try {
            Process proc = Runtime.getRuntime().exec(new String[]{
                    "powershell", "-Command",
                    "Get-Service | Where-Object {$_.Status -eq 'Running'} | " +
                            "Select-Object Name,DisplayName | Format-List"
            });
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(proc.getInputStream())
            )) {
                String name = "";
                String displayName = "";
                String line;
                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    if (line.startsWith("Name")) {
                        name = line.substring(
                                line.indexOf(':') + 1
                        ).trim().toLowerCase();
                    } else if (line.startsWith("DisplayName")) {
                        displayName = line.substring(
                                line.indexOf(':') + 1
                        ).trim();
                        if (!name.isEmpty()) {
                            String combined = name + " " + displayName.toLowerCase();
                            for (String sus : SUSPICIOUS_SERVICES) {
                                if (combined.contains(sus)) {
                                    findings.add(new Finding(
                                            "service", name,
                                            Severity.HIGH,
                                            "Suspicious service: " + displayName
                                    ));
                                }
                            }
                        }
                    }
                }
            }
            proc.waitFor();
        } catch (Exception ignored) {
        }
    }

    private static void scanAntiDebug(List<Finding> findings) {
        RuntimeMXBean runtime = ManagementFactory.getRuntimeMXBean();

        for (String arg : runtime.getInputArguments()) {
            String lower = arg.toLowerCase();
            if (lower.contains("jdwp")) {
                findings.add(new Finding(
                        "anti_debug", "jdwp",
                        Severity.HIGH,
                        "JDWP debug agent active: " + arg
                ));
                return;
            }
            if (lower.contains("suspend=n")) {
                findings.add(new Finding(
                        "anti_debug", "suspend_n",
                        Severity.MEDIUM,
                        "Debug suspend=n detected"
                ));
            }
        }

        if (isWindows()) {
            try {
                Process proc = Runtime.getRuntime().exec(new String[]{
                        "wmic", "process", "where",
                        "name='javaw.exe'",
                        "get", "CommandLine", "/FORMAT:LIST"
                });
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(proc.getInputStream())
                )) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (line.toLowerCase().contains("jdwp")
                                || line.toLowerCase().contains("suspend=n")) {
                            findings.add(new Finding(
                                    "anti_debug", "external_jdwp",
                                    Severity.HIGH,
                                    "JDWP in javaw cmdline via wmic"
                            ));
                            break;
                        }
                    }
                }
                proc.waitFor();
            } catch (Exception ignored) {
            }
        }
    }

    private static void parseRegOutput(
            Process proc, String category, List<Finding> findings
    ) {
        try {
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(proc.getInputStream())
            );
            String line;
            Set<String> cheatTerms = new HashSet<>();
            cheatTerms.addAll(KNOWN_INJECTORS);
            cheatTerms.addAll(KNOWN_CHEAT_PROCESSES);
            cheatTerms.addAll(KNOWN_SUSPICIOUS_DLLS);

            while ((line = reader.readLine()) != null) {
                String lower = line.toLowerCase();
                for (String cheat : cheatTerms) {
                    String term = cheat.replace(".exe", "")
                            .replace(".dll", "");
                    if (lower.contains(term)) {
                        findings.add(new Finding(
                                category, cheat,
                                Severity.HIGH,
                                "Registry hit: " + line.trim()
                        ));
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    private static String extractCsvField(String csvLine, int index) {
        try {
            String[] parts = csvLine.split(",");
            if (parts.length > index) {
                return parts[index]
                        .replace("\"", "")
                        .trim()
                        .toLowerCase();
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    private static boolean isKnownAgent(String path) {
        String lower = path.toLowerCase();
        return lower.contains("spark")
                || lower.contains("paper")
                || lower.contains("purpur")
                || lower.contains("fabric")
                || lower.contains("asyncprofiler")
                || lower.contains("jfr")
                || lower.contains("yourkit")
                || lower.contains("appdynamics")
                || lower.contains("newrelic")
                || lower.contains("datadog")
                || lower.contains("openapm")
                || lower.contains("opentelemetry");
    }

    private static boolean isVanillaAgent(String value) {
        String lower = value.toLowerCase();
        return lower.contains("jfr")
                || lower.contains("management")
                || lower.contains("jdwp")
                || lower.contains("profiler")
                || lower.contains("visualvm")
                || lower.contains("bctrace");
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "")
                .toLowerCase()
                .contains("win");
    }
}
