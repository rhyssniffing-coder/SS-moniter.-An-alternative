package com.skiye.ssmonitor.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicLong;

public final class SSMonitorClient implements ClientModInitializer {
    public static final String MOD_ID = "ssmonitor";
    public static final String VERSION = "2.1.0";

    private static SSMonitorClient instance;

    private SSMonitorConfig config;
    private TelemetryManager telemetry;
    private InputTracker inputTracker;

    private long tickCounter;
    private long lastScanTick;
    private long lastInputTick;
    private final AtomicLong reportSequence = new AtomicLong();

    @Override
    public void onInitializeClient() {
        instance = this;

        Path configPath = FabricLoader.getInstance()
                .getConfigDir()
                .resolve("ssmonitor.properties");

        config = SSMonitorConfig.load(configPath);
        inputTracker = new InputTracker();
        telemetry = new TelemetryManager(
                config,
                reportSequence,
                inputTracker
        );

        SSMonitorControlChannel.register(telemetry);

        registerCommands();

        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);

        ClientPlayConnectionEvents.JOIN.register(
                (handler, sender, client) -> telemetry.onServerJoin(client)
        );

        ClientPlayConnectionEvents.DISCONNECT.register(
                (handler, client) -> telemetry.onServerDisconnect()
        );
    }

    private void registerCommands() {
        ClientCommandRegistrationCallback.EVENT.register(
                (dispatcher, registryAccess) -> dispatcher.register(
                        ClientCommandManager.literal("ssmonitor")
                                .then(
                                        ClientCommandManager.literal("status")
                                                .executes(context -> {
                                                    sendMessage(
                                                            "running="
                                                                    + telemetry.isRunning()
                                                                    + " queue="
                                                                    + telemetry.getQueueSize()
                                                                    + " failures="
                                                                    + telemetry.getConsecutiveFailures()
                                                                    + " session="
                                                                    + telemetry.hasSession()
                                                                    + " endpoint="
                                                                    + telemetry.getEndpointStatus()
                                                                    + " last_failure="
                                                                    + telemetry.getLastFailure()
                                                    );
                                                    return 1;
                                                })
                                )
                                .then(
                                        ClientCommandManager.literal("report")
                                                .executes(context -> {
                                                    if (!telemetry.isRunning()) {
                                                        sendMessage("This server has not enabled SS Monitor for this session.");
                                                        return 0;
                                                    }

                                                    telemetry.sendFullReport(
                                                            class_310.method_1551(),
                                                            "MANUAL_REPORT"
                                                    );

                                                    sendMessage("Report queued.");
                                                    return 1;
                                                })
                                )
                                .then(
                                        ClientCommandManager.literal("scan")
                                                .executes(context -> {
                                                    ExternalDllScanner.DllScanResult result =
                                                            ExternalDllScanner.scan();
                                                    sendMessage("Findings: C="
                                                            + result.criticalCount()
                                                            + " H=" + result.highCount()
                                                            + " M=" + result.mediumCount());
                                                    if (!result.runningInjectors().isEmpty())
                                                        sendMessage("Injectors: " + result.runningInjectors());
                                                    if (!result.cheatMods().isEmpty())
                                                        sendMessage("Cheat mods: " + result.cheatMods());
                                                    if (!result.prefetchMatches().isEmpty())
                                                        sendMessage("Prefetch: " + result.prefetchMatches());
                                                    if (!result.hookDetections().isEmpty())
                                                        sendMessage("Hooks: " + result.hookDetections());
                                                    if (!result.windowTitles().isEmpty())
                                                        sendMessage("Windows: " + result.windowTitles());
                                                    if (!result.suspiciousServices().isEmpty())
                                                        sendMessage("Services: " + result.suspiciousServices());
                                                    if (result.antiDebugDetected())
                                                        sendMessage("Anti-debug: detected");
                                                    return 1;
                                                })
                                )
                )
        );
    }

    private void onClientTick(class_310 client) {
        tickCounter++;

        if (!telemetry.isRunning()) {
            return;
        }

        telemetry.processClickTiming();

        int inputTicks = Math.max(
                1,
                config.getInputSampleTicks()
        );

        if (tickCounter - lastInputTick >= inputTicks) {
            lastInputTick = tickCounter;
            telemetry.processInput(client);
            telemetry.processScreenState(client);
        }

        long scanTicks = Math.max(
                20,
                config.getScanSeconds() * 20L
        );

        if (
                tickCounter - lastScanTick >= scanTicks
                        || lastScanTick == 0
        ) {
            lastScanTick = tickCounter;
            telemetry.sendFullReport(
                    client,
                    lastScanTick == scanTicks
                            ? "INITIAL_REPORT"
                            : "PERIODIC_SCAN"
            );
        }
    }

    public SSMonitorConfig getConfig() {
        return config;
    }

    public TelemetryManager getTelemetry() {
        return telemetry;
    }

    public static SSMonitorClient getInstance() {
        return instance;
    }

    public static void sendMessage(String message) {
        class_310 client = class_310.method_1551();

        if (client.field_1724 != null) {
            client.field_1724.method_7353(
                    class_2561.method_43470("[SS Monitor] " + message),
                    false
            );
        }
    }

    public static void sendWarning(String message) {
        class_310 client = class_310.method_1551();
        class_2561 warning = class_2561.method_43470("[SS Monitor] " + message);
        if (client.field_1705 != null) {
            client.field_1705.method_1758(warning, false);
        }
        if (client.field_1724 != null) {
            client.field_1724.method_7353(warning, false);
        }
    }
}
