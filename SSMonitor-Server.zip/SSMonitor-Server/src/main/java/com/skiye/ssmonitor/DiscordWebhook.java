package com.skiye.ssmonitor;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;

public final class DiscordWebhook {

    private final String webhookUrl;
    private boolean enabled;

    public DiscordWebhook(String webhookUrl) {
        this.webhookUrl = webhookUrl;
        this.enabled = webhookUrl != null
                && !webhookUrl.isEmpty()
                && webhookUrl.startsWith("https://discord.com/api/webhooks/");
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public void sendEmbed(EmbedBuilder embed) {
        if (!enabled) return;

        CompletableFuture.runAsync(() -> {
            try {
                String json = embed.build();
                sendPost(json);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public void sendText(String text) {
        if (!enabled) return;

        CompletableFuture.runAsync(() -> {
            try {
                String json = "{\"content\":\""
                        + escapeJson(text) + "\"}";
                sendPost(json);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private void sendPost(String jsonBody) throws IOException {
        URL url = new URL(webhookUrl);
        HttpURLConnection conn =
                (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("User-Agent", "SSMonitor/2.1");
        conn.setDoOutput(true);
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(5000);

        byte[] body = jsonBody.getBytes(StandardCharsets.UTF_8);
        conn.setFixedLengthStreamingMode(body.length);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body);
        }

        int code = conn.getResponseCode();
        conn.disconnect();

        if (code == 429) {
            try {
                Thread.sleep(2000);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public static String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    public static final class EmbedBuilder {
        private String title;
        private String description;
        private int color;
        private final StringBuilder fields = new StringBuilder();

        public EmbedBuilder title(String t) {
            this.title = t;
            return this;
        }

        public EmbedBuilder description(String d) {
            this.description = d;
            return this;
        }

        public EmbedBuilder color(int c) {
            this.color = c;
            return this;
        }

        public EmbedBuilder field(String name, String value, boolean inline) {
            if (fields.length() > 0) fields.append(",");
            fields.append("{\"name\":\"")
                    .append(escapeJson(name))
                    .append("\",\"value\":\"")
                    .append(escapeJson(value))
                    .append("\",\"inline\":")
                    .append(inline)
                    .append("}");
            return this;
        }

        public String build() {
            StringBuilder sb = new StringBuilder();
            sb.append("{\"embeds\":[{");

            if (title != null) {
                sb.append("\"title\":\"").append(escapeJson(title)).append("\",");
            }
            if (description != null) {
                sb.append("\"description\":\"").append(escapeJson(description)).append("\",");
            }
            if (color != 0) {
                sb.append("\"color\":").append(color).append(",");
            }
            if (fields.length() > 0) {
                sb.append("\"fields\":[").append(fields).append("],");
            }

            sb.append("\"footer\":{\"text\":\"SS Monitor\"},");
            sb.append("\"timestamp\":\"")
                    .append(java.time.Instant.now().toString())
                    .append("\"");

            sb.append("}]}");
            return sb.toString();
        }
    }
}
