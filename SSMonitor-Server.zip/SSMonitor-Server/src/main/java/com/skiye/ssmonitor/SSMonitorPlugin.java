package com.skiye.ssmonitor;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.zip.Inflater;

public final class SSMonitorPlugin extends JavaPlugin
        implements PluginMessageListener {

    private DiscordWebhook discord;
    private final Gson gson = new Gson();
    private final Map<UUID, Long> lastReportTime = new HashMap<>();
    private boolean reportToChat;
    private int cooldownSeconds;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        String webhook = getConfig()
                .getString("discord.webhook", "");
        discord = new DiscordWebhook(webhook);
        reportToChat = getConfig()
                .getBoolean("alert.chat", true);
        cooldownSeconds = getConfig()
                .getInt("cooldown-seconds", 60);

        getServer().getMessenger()
                .registerIncomingPluginChannel(
                        this,
                        "ssmonitor:report",
                        this
                );

        getServer().getMessenger()
                .registerOutgoingPluginChannel(
                        this,
                        "ssmonitor:control"
                );

        getCommand("ssmonitor")
                .setExecutor(new SSMonitorCommand(this));

        getLogger().info("SS Monitor server plugin enabled.");
    }

    @Override
    public void onDisable() {
        getServer().getMessenger()
                .unregisterIncomingPluginChannel(this);
        getServer().getMessenger()
                .unregisterOutgoingPluginChannel(this);
        getLogger().info("SS Monitor server plugin disabled.");
    }

    @Override
    public void onPluginMessageReceived(
            String channel,
            Player player,
            byte[] message
    ) {
        if (!channel.equals("ssmonitor:report")) return;

        try {
            byte[] decompressed = decompress(message);
            String json = new String(
                    decompressed, StandardCharsets.UTF_8
            );

            JsonObject report = gson.fromJson(
                    json, JsonObject.class
            );

            processReport(player, report);

        } catch (Exception e) {
            getLogger().log(Level.WARNING,
                    "Failed to process SS Monitor report from "
                            + player.getName(), e
            );
        }
    }

    private void processReport(
            Player player, JsonObject report
    ) {
        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();

        Long lastTime = lastReportTime.get(uuid);
        if (lastTime != null
                && (now - lastTime) < cooldownSeconds * 1000L) {
            return;
        }
        lastReportTime.put(uuid, now);

        if (!report.has("external_scan")) return;

        JsonObject scan = report.getAsJsonObject("external_scan");

        int critical = scan.has("critical")
                ? scan.get("critical").getAsInt() : 0;
        int high = scan.has("high")
                ? scan.get("high").getAsInt() : 0;
        int medium = scan.has("medium")
                ? scan.get("medium").getAsInt() : 0;

        if (critical == 0 && high == 0 && medium == 0) return;

        String serverName = getConfig()
                .getString("server-name", "Server");

        DiscordWebhook.EmbedBuilder embed =
                new DiscordWebhook.EmbedBuilder();

        int severityColor;
        String severityLabel;
        if (critical > 0) {
            severityColor = 0xFF0000;
            severityLabel = "CRITICAL";
        } else if (high > 0) {
            severityColor = 0xFF6600;
            severityLabel = "HIGH";
        } else {
            severityColor = 0xFFCC00;
            severityLabel = "MEDIUM";
        }

        embed.title(player.getName() + " — " + severityLabel)
                .color(severityColor);

        StringBuilder desc = new StringBuilder();
        desc.append("**Player:** ")
                .append(player.getName())
                .append(" (`")
                .append(uuid.toString().substring(0, 8))
                .append("`)\n");
        desc.append("**Server:** ").append(serverName).append("\n");
        desc.append("**Critical:** ").append(critical)
                .append(" **High:** ").append(high)
                .append(" **Medium:** ").append(medium)
                .append("\n");

        embed.description(desc.toString());

        if (scan.has("running_injectors")) {
            JsonArray arr = scan.getAsJsonArray("running_injectors");
            if (arr.size() > 0) {
                embed.field("Injectors Running",
                        arrayToString(arr), false);
            }
        }

        if (scan.has("cheat_mods")) {
            JsonArray arr = scan.getAsJsonArray("cheat_mods");
            if (arr.size() > 0) {
                embed.field("Cheat Mods Detected",
                        arrayToString(arr), false);
            }
        }

        if (scan.has("suspicious_processes")) {
            JsonArray arr = scan.getAsJsonArray("suspicious_processes");
            if (arr.size() > 0) {
                embed.field("Suspicious Processes",
                        arrayToString(arr), false);
            }
        }

        if (scan.has("prefetch_matches")) {
            JsonArray arr = scan.getAsJsonArray("prefetch_matches");
            if (arr.size() > 0) {
                embed.field("Prefetch History",
                        arrayToString(arr), false);
            }
        }

        if (scan.has("amcache_hits")) {
            JsonArray arr = scan.getAsJsonArray("amcache_hits");
            if (arr.size() > 0) {
                embed.field("AMCache Hits",
                        arrayToString(arr), false);
            }
        }

        if (scan.has("bam_entries")) {
            JsonArray arr = scan.getAsJsonArray("bam_entries");
            if (arr.size() > 0) {
                embed.field("BAM Entries",
                        arrayToString(arr), false);
            }
        }

        if (scan.has("hook_detections")) {
            JsonArray arr = scan.getAsJsonArray("hook_detections");
            if (arr.size() > 0) {
                embed.field("Hook Detections",
                        arrayToString(arr), false);
            }
        }

        if (scan.has("window_titles")) {
            JsonArray arr = scan.getAsJsonArray("window_titles");
            if (arr.size() > 0) {
                embed.field("Suspicious Windows",
                        arrayToString(arr), false);
            }
        }

        if (scan.has("suspicious_services")) {
            JsonArray arr = scan.getAsJsonArray("suspicious_services");
            if (arr.size() > 0) {
                embed.field("Suspicious Services",
                        arrayToString(arr), false);
            }
        }

        if (scan.has("anti_debug_detected")
                && scan.get("anti_debug_detected").getAsBoolean()) {
            embed.field("Anti-Debug", "Detected", true);
        }

        if (scan.has("has_java_agents")
                && scan.get("has_java_agents").getAsBoolean()) {
            JsonArray arr = scan.getAsJsonArray("agent_paths");
            embed.field("Java Agents",
                    arr.size() > 0 ? arrayToString(arr) : "Unknown",
                    true);
        }

        if (scan.has("findings")) {
            JsonArray findings = scan.getAsJsonArray("findings");
            StringBuilder topFindings = new StringBuilder();
            int count = 0;
            for (JsonElement el : findings) {
                JsonObject f = el.getAsJsonObject();
                String sev = f.has("sev")
                        ? f.get("sev").getAsString() : "?";
                String cat = f.has("cat")
                        ? f.get("cat").getAsString() : "?";
                String name = f.has("name")
                        ? f.get("name").getAsString() : "?";
                String detail = f.has("detail")
                        ? f.get("detail").getAsString() : "";
                if (sev.equals("CRITICAL")
                        || sev.equals("HIGH")) {
                    if (count < 10) {
                        topFindings.append("`")
                                .append(sev).append("` ")
                                .append(cat).append(": ")
                                .append(name);
                        if (!detail.isEmpty()) {
                            topFindings.append(" — ")
                                    .append(truncate(detail, 80));
                        }
                        topFindings.append("\n");
                    }
                    count++;
                }
            }
            if (topFindings.length() > 0) {
                if (count > 10) {
                    topFindings.append("... and ")
                            .append(count - 10)
                            .append(" more\n");
                }
                embed.field("Top Findings",
                        topFindings.toString(), false);
            }
        }

        discord.sendEmbed(embed);

        if (reportToChat) {
            String alert = getConfig()
                    .getString("alert.chat-message",
                            "&c[SS] &e{player} flagged — {severity}");
            alert = alert.replace("{player}", player.getName())
                    .replace("{severity}", severityLabel)
                    .replace("{critical}", String.valueOf(critical))
                    .replace("{high}", String.valueOf(high))
                    .replace("{medium}", String.valueOf(medium));

            String finalAlert = alert;
            Bukkit.getScheduler().runTask(this, () -> {
                for (Player staff : Bukkit.getOnlinePlayers()) {
                    if (staff.hasPermission("ssmonitor.alert")) {
                        staff.sendMessage(
                                org.bukkit.ChatColor.translateAlternateColorCodes(
                                        '&', finalAlert
                                )
                        );
                    }
                }
            });
        }
    }

    private byte[] decompress(byte[] data) throws IOException {
        Inflater inflater = new Inflater();
        inflater.setInput(data);

        ByteArrayOutputStream bos =
                new ByteArrayOutputStream(data.length);
        byte[] buf = new byte[1024];

        try {
            while (!inflater.finished()) {
                int count = inflater.inflate(buf);
                bos.write(buf, 0, count);
            }
        } catch (Exception e) {
            throw new IOException("Decompression failed", e);
        } finally {
            inflater.end();
        }

        return bos.toByteArray();
    }

    private String arrayToString(JsonArray arr) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < arr.size(); i++) {
            if (i > 0) sb.append("\n");
            sb.append("• ").append(arr.get(i).getAsString());
        }
        if (sb.length() > 1000) {
            return sb.substring(0, 1000) + "\n...";
        }
        return sb.toString();
    }

    private String truncate(String s, int max) {
        if (s.length() <= max) return s;
        return s.substring(0, max) + "...";
    }

    DiscordWebhook getDiscord() {
        return discord;
    }
}
