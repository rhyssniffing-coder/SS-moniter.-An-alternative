package com.skiye.ssmonitor;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class SSMonitorCommand
        implements CommandExecutor, TabCompleter {

    private final SSMonitorPlugin plugin;

    public SSMonitorCommand(SSMonitorPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(
            CommandSender sender,
            Command command,
            String label,
            String[] args
    ) {
        if (!sender.hasPermission("ssmonitor.admin")) {
            sender.sendMessage(
                    "§cNo permission."
            );
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.reloadConfig();
                String webhook = plugin.getConfig()
                        .getString("discord.webhook", "");
                plugin.getDiscord()
                        .setEnabled(webhook.startsWith(
                                "https://discord.com/api/webhooks/"
                        ));
                plugin.getDiscord()
                        .setEnabled(!webhook.isEmpty());
                sender.sendMessage(
                        "§aConfig reloaded."
                );
            }
            case "test" -> {
                if (!plugin.getDiscord().isEnabled()) {
                    sender.sendMessage(
                            "§cWebhook not configured."
                    );
                    return true;
                }
                DiscordWebhook.EmbedBuilder embed =
                        new DiscordWebhook.EmbedBuilder();
                embed.title("SS Monitor — Test")
                        .description("Test notification from "
                                + plugin.getServer()
                                .getServerName())
                        .color(0x00AAFF);
                plugin.getDiscord().sendEmbed(embed);
                sender.sendMessage(
                        "§aTest webhook sent."
                );
            }
            case "status" -> {
                String webhook = plugin.getConfig()
                        .getString("discord.webhook", "");
                boolean hasHook = !webhook.isEmpty()
                        && webhook.startsWith(
                        "https://discord.com/api/webhooks/"
                );
                sender.sendMessage(
                        "§eWebhook: "
                                + (hasHook ? "§aConfigured" : "§cNot set")
                );
                sender.sendMessage(
                        "§eChat alerts: "
                                + (plugin.getConfig()
                                .getBoolean("alert.chat")
                                ? "§aOn" : "§cOff")
                );
                sender.sendMessage(
                        "§eCooldown: "
                                + plugin.getConfig()
                                .getInt("cooldown-seconds")
                                + "s"
                );
            }
            default -> sendHelp(sender);
        }

        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage("§e/ssmonitor reload §7— Reload config");
        sender.sendMessage("§e/ssmonitor test §7— Send test webhook");
        sender.sendMessage("§e/ssmonitor status §7— Show status");
    }

    @Override
    public List<String> onTabComplete(
            CommandSender sender,
            Command command,
            String label,
            String[] args
    ) {
        if (!sender.hasPermission("ssmonitor.admin")) {
            return List.of();
        }
        if (args.length == 1) {
            return Arrays.stream(
                    new String[]{"reload", "test", "status"}
            ).filter(s -> s.startsWith(args[0].toLowerCase()))
                    .toList();
        }
        return List.of();
    }
}
